RiptOPL test copy for the in-game menu yellow screen (issue #364)
Version on its title screen: v1.2.0-Beta-4261-52d35af (Korium)
SHA-256 of RIPTOPL.ELF: a5654b0a756fb0b02d2f939d124fac58e2e7f960ee66e7a4c35b0e49791320e9

This is a test copy, not a release. It plays like the normal Korium build. The only
difference: when the in-game menu fails with the YELLOW blink, it then flashes four
more colours that say which part of the game was still busy.

What to do
1. Put this RIPTOPL.ELF in place of the RIPTOPL.ELF you normally start (keep your
   other files as they are). Keep Debug Colors on, as it is now.
2. Start the game that gives you the yellow screen.
3. Press the in-game menu combo (R1+L1+R2+L2+START+SELECT) and keep holding it until
   the screen blinks yellow. Then let go.
4. After the yellow blinks, the screen flashes, in this order and each colour as a
   group:  RED, GREEN, BLUE, WHITE  - and then the whole set once more.
   Count how many times each colour flashes. Filming it with a phone is easiest.

Please post, on the issue:
 - the number of flashes for red, green, blue and white (or the video),
 - the name of the game.
If the menu opens this time, tell us that instead - that is a good result too.
