RiptOPL test copy 2 for the in-game menu yellow screen (issue #364)
Version on its title screen: v1.2.0-Beta-4262-eab1009 (Korium)
SHA-256 of RIPTOPL.ELF: 95e1ed5c7363feda59e7d8f9a42b5855d910133ec4759befdfc177e17e7c82d6

This is a test copy, not a release. It plays like the normal Korium build. The only
difference: when the in-game menu cannot open because the game is still busy, it now
reports why FIRST, before anything is reset, and marks how far the reset gets.

What to do
1. Put this RIPTOPL.ELF in place of the RIPTOPL.ELF you normally start (keep your
   other files as they are). Keep Debug Colors on, as it is now.
2. Start the game that gives you the yellow screen.
3. Press the in-game menu combo (R1+L1+R2+L2+START+SELECT) and keep holding it for
   about two seconds, then let go.
4. Watch the screen. In order you may see:
   - RED, GREEN, BLUE, WHITE flashes, as a group, then that group once more
     (count the flashes of each colour),
   - one ORANGE flash,
   - three YELLOW flashes.
   Filming it with a phone is easiest.

Please post, on the issue:
 - which of those you saw (even "only the yellow"), with the flash counts if you saw them,
 - the name of the game.
If the menu opens this time, tell us that instead - that is a good result too.
